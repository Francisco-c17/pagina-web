import { BrowserModule } from "@angular/platform-browser";
import { LOCALE_ID, NgModule } from "@angular/core"; //LOCALE_ID:Para fecha a español

import { AppComponent } from "./app.component";

import localeEs from "@angular/common/locales/es"; //Para fecha a español
import { registerLocaleData } from "@angular/common"; //Para fecha a español
registerLocaleData(localeEs); //Para fecha a español

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule],
  providers: [{ provide: LOCALE_ID, useValue: "es" }],
  bootstrap: [AppComponent]
})
export class AppModule {}
