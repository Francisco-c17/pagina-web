import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable({
  providedIn: "root"
})
export class SpotifyService {
  constructor(private http: HttpClient) {
    console.log("Spotify service Listo");
  }

  getNewRelease() {
    const headers = new HttpHeaders({
      Authorization:
        "Bearer BQDGwBXXLaHYw2akmm7_h46Fi20d3_7L1kQ7DZvrz8Rd5CEoYky7iW4-Swxn_anIvsCMXLCbkII7SwQe538"
    });

    return this.http.get("https://api.spotify.com/v1/browse/new-releases", {
      headers
    });
  }

  getArtista(termino: string) {
    const headers = new HttpHeaders({
      Authorization:
        "Bearer BQDGwBXXLaHYw2akmm7_h46Fi20d3_7L1kQ7DZvrz8Rd5CEoYky7iW4-Swxn_anIvsCMXLCbkII7SwQe538"
    });

    return this.http.get(
      `https://api.spotify.com/v1/search?q=${termino}&type=artist&limit=15`,
      {
        headers
      }
    );
  }
}
