import { Component, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { SpotifyService } from "src/app/services/spotify.service";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styles: []
})
export class HomeComponent {
  // paises: any[] = [];
  //http://restcountries.eu/#api-endpoints-language
  // constructor(private http: HttpClient) {
  //   this.http
  //     .get("https://restcountries.eu/rest/v2/lang/es")
  //     .subscribe((resp: any) => {
  //       this.paises = resp;
  //     });
  // }
  constructor(private spotify: SpotifyService) {
    this.spotify.getNewRelease();
  }
}
