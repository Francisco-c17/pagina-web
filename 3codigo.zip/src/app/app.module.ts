import { BrowserModule } from "@angular/platform-browser";
import { LOCALE_ID, NgModule } from "@angular/core"; //LOCALE_ID:Para fecha a español

import { AppComponent } from "./app.component";
import { CapitalizadoPipe } from "./pipes/capitalizado.pipe";

import localeEs from "@angular/common/locales/es"; //Para fecha a español
import { registerLocaleData } from "@angular/common";
import { DomseguroPipe } from './pipes/domseguro.pipe';
import { ContraseñapipePipe } from './pipes/contraseñapipe.pipe'; //Para fecha a español
registerLocaleData(localeEs); //Para fecha a español

@NgModule({
  declarations: [AppComponent, CapitalizadoPipe, DomseguroPipe, ContraseñapipePipe],
  imports: [BrowserModule],
  providers: [{ provide: LOCALE_ID, useValue: "es" }],
  bootstrap: [AppComponent]
})
export class AppModule {}
